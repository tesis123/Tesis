<?php   	 	                                                                                                                  					      

class Usuario extends CI_Controller{
	
	  function __construct() {
       parent::__construct();
		$this -> load -> model('Model_Usuario');
	}

	public function Index (){
		$data['titulo']= 'Pagina Principal';
		$data['query'] = $this -> Model_Usuario -> getAll();

		$this -> load ->view ('Plantilla/Header', $data);
		$this -> load ->view ('Usuario/Index');
		$this -> load ->view ('Plantilla/Footer');
	}

	public function Agregar(){
		$data['titulo']= 'Agregar';
		$this -> load ->view ('Plantilla/Header',$data);
		$this -> load ->view ('Usuario/Agregar');
		$this -> load ->view ('Plantilla/Footer');
	}



	public function AgregarUsuario(){
		$this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');

        $this -> form_validation -> set_rules('nusuario','usuario','required');
        $this -> form_validation -> set_rules('nclave','clave','required');
        $this -> form_validation -> set_rules('nid_perfil','id_perfil','required');
        $this -> form_validation -> set_rules('nestado','estado','required');
        $this -> form_validation -> set_rules('ncedula','cedula','required');
		$this -> form_validation -> set_rules('nnombre','nombre','required');
		$this -> form_validation -> set_rules('napellido','Direccion','required');
		$this -> form_validation -> set_rules('nemail','email','required');



		if($this->form_validation->run() == FALSE){
			//ERROR

			$data['titulo']= 'Agregar Usuario';

			$this -> load -> view ('Plantilla/Header', $data);
			$this -> load -> view ('Usuario/Agregar');
			$this -> load -> view ('Plantilla/Footer');
		}else {
			//OK
			$data = array(
				'usuario' => $this -> input -> post('nusuario'),
				'clave' => $this -> input -> post('nclave'),
				'id_perfil' => $this -> input -> post('nid_perfil'),
				'estado' => $this -> input -> post('nestado'),
				'cedula' => $this -> input -> post('ncedula'),
				'nombre' => $this -> input -> post('nnombre'),
				'apellido' => $this -> input -> post('napellido'),
				'email' => $this -> input -> post('nemail')
			);
			
			$this -> Model_Usuario -> insertar($data);
			redirect(base_url(), 'usuario');
		}

}

}
?>