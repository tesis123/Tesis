<?php   	 	                                                            
class Perfil extends CI_Controller{
	
	  function __construct() {
       parent::__construct();
		$this -> load -> model('Model_Perfil');
	}

	public function Index (){
		$data['titulo']= 'Pagina Principal';
		$data['query'] = $this -> Model_Perfil -> getAll();

		$this -> load ->view ('Plantilla/Header', $data);
		$this -> load ->view ('Perfil/Index');
		$this -> load ->view ('Plantilla/Footer');
	}

	public function Agregar(){
		$data['titulo']= 'Agregar';
		$this -> load ->view ('Plantilla/Header',$data);
		$this -> load ->view ('Perfil/Agregar');
		$this -> load ->view ('Plantilla/Footer');
	}

	public function AgregarPerfil(){
		$this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');


		$this -> form_validation -> set_rules('nnombre','Nombre','required');
	
		$this -> form_validation -> set_rules('nestado','Estado','required');

	

		if($this->form_validation->run() == FALSE){
			//ERROR

			$data['titulo']= 'Agregar Perfil';

			$this -> load -> view ('Plantilla/Header', $data);
			$this -> load -> view ('Perfil/Agregar');
			$this -> load -> view ('Plantilla/Footer');
		}else {
			//OK
			$data = array(
				'Nombre' => $this -> input -> post('nnombre'),
				'Estado' => $this -> input -> post('nestado'),
			);
			
			$this -> Model_Perfil -> insertar($data);
			redirect(base_url(), 'perfil');
		}


	}

	public function Editar(){
		$data['titulo']= 'Editar';
		$this -> load ->view ('Plantilla/Header',$data);
		$this -> load ->view ('Perfil/Editar');
		$this -> load ->view ('Plantilla/Footer');
	}

	public function EditarPerfil($id){
		

		$id1['id'] = $id;
		$this->load->model('Model_Perfil');
		$record = $this -> Model_Perfil -> getAllRecords($id);
		$this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
		$this -> form_validation -> set_rules('nnombre','Nombre','required');
		$this -> form_validation -> set_rules('nestado','Estado','required');

	

		if($this->form_validation->run() == FALSE){
			//ERROR

			$data['titulo']= 'Editar Perfil';

			$this -> load -> view ('Plantilla/Header', $data);
			$this -> load -> view ('Perfil/Editar', ['record'=> $record]);
			$this -> load -> view ('Plantilla/Footer');
		}else {
			//OK
			$data = array(
				'Nombre' => $this -> input -> post('nnombre'),
				'Estado' => $this -> input -> post('nestado'),
			);
			$this-> db -> where('id_perfil', $id);
			$this -> Model_Perfil -> editar($data);
			redirect(base_url(), 'perfil');
		}	
	}
}

?>