<?php   	 	                                                                                                                  					      

class Paciente extends CI_Controller{
	
	  function __construct() {
       parent::__construct();
		$this -> load -> model('Model_Paciente');
	}

	public function Index (){
		$data['titulo']= 'Pagina Principal';
		$data['query'] = $this -> Model_Paciente -> getAll();

		$this -> load ->view ('Plantilla/Header', $data);
		$this -> load ->view ('Paciente/Index');
		$this -> load ->view ('Plantilla/Footer');
	}

	public function Agregar(){
		$data['titulo']= 'Agregar';
		$this -> load ->view ('Plantilla/Header',$data);
		$this -> load ->view ('Paciente/Agregar');
		$this -> load ->view ('Plantilla/Footer');
	}



	public function AgregarPaciente(){
		$this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');

        $this -> form_validation -> set_rules('nestado','estado','required');
		$this -> form_validation -> set_rules('nnombre','nom_paciente','required');
		$this -> form_validation -> set_rules('napellido','apell_paciente','required');
		$this -> form_validation -> set_rules('ndireccion','direccion','required');
		$this -> form_validation -> set_rules('ntelefono','telefono','required');
		$this -> form_validation -> set_rules('nemail','email','required');
		$this -> form_validation -> set_rules('nsintomas','sintomas','required');
		$this -> form_validation -> set_rules('ndrogueria','drogueria','required');
		$this -> form_validation -> set_rules('nlista_llamada','lista_llamada','required');
		$this -> form_validation -> set_rules('nid_caso','id_caso','required');
		$this -> form_validation -> set_rules('nid_usuario','id_usuario','required');

		if($this->form_validation->run() == FALSE){
			//ERROR

			$data['titulo']= 'Agregar Paciente';

			$this -> load -> view ('Plantilla/Header', $data);
			$this -> load -> view ('Paciente/Agregar');
			$this -> load -> view ('Plantilla/Footer');
		}else {
			//OK
			$data = array(
				'estado' => $this -> input -> post('nestado'),
				'nom_paciente' => $this -> input -> post('nnombre'),
				'apell_paciente' => $this -> input -> post('napellido'),
				'direccion' => $this -> input -> post('ndireccion'),
				'telefono' => $this -> input -> post('ntelefono'),
				'email' => $this -> input -> post('nemail'),
				'sintomas' => $this -> input -> post('nsintomas'),
				'drogueria' => $this -> input -> post('ndrogueria'),
				'lista_llamada' => $this -> input -> post('nlista_llamada'),			
				'id_caso' => $this -> input -> post('nid_caso'),
				'id_usuario' => $this -> input -> post('nid_usuario')			
			);
			
			$this -> Model_Paciente -> insertar($data);
			redirect(base_url(), 'paciente');
		}

}

	public function Editar(){
		$this->load->model('Model_Perfil');
		$datos = $this -> Model_Perfil -> getAllRecords('1');
		$data['titulo']= 'Editar';
		$this -> load ->view ('Plantilla/Header',$data);
		$this -> load ->view ('Paciente/Editar',['record'=> $datos]);
		$this -> load ->view ('Plantilla/Footer');
	}

}
?>