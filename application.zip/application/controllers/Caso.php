<?php   	 	                                                                                                                  					      

class Caso extends CI_Controller{
	
	  function __construct() {
       parent::__construct();
		$this -> load -> model('Model_Caso');
	}

	public function Index (){
		$data['titulo']= 'Pagina Principal';
		$data['query'] = $this -> Model_Caso -> getAll();

		$this -> load ->view ('Plantilla/Header', $data);
		$this -> load ->view ('Caso/Index');
		$this -> load ->view ('Plantilla/Footer');
	}

	public function Agregar(){
		$data['titulo']= 'Agregar';
		$this -> load ->view ('Plantilla/Header',$data);
		$this -> load ->view ('Caso/Agregar');
		$this -> load ->view ('Plantilla/Footer');
	}



	public function AgregarCaso(){
		$this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');

        $this -> form_validation -> set_rules('nestado','nom_estado','required');


		if($this->form_validation->run() == FALSE){
			//ERROR

			$data['titulo']= 'Agregar Caso';

			$this -> load -> view ('Plantilla/Header', $data);
			$this -> load -> view ('Caso/Agregar');
			$this -> load -> view ('Plantilla/Footer');
		}else {
			//OK
			$data = array(
				'nom_estado' => $this -> input -> post('nestado')
			);
			
			$this -> Model_Caso -> insertar($data);
			redirect(base_url(), 'caso');
		}

}

}
?>