<?php
class Home extends CI_Controller{
	public function index(){
		$data['titulo']= "Agenda Web";
		$this -> load ->view ('Plantilla/Header', $data);
		//$this -> load ->view ('Plantilla/Lateral');
		$this -> load ->view ('Home/Index');
		$this -> load ->view ('Plantilla/Footer');
	}
}
?>