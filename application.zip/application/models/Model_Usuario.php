<?php

class Model_Usuario extends CI_Model{
	function insertar($data){
		$this -> db -> insert('usuario',$data);
		}


	function getAll(){
		$query = $this -> db -> get('usuario');
		return $query -> result();
	}
}

?>
