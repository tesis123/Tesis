<?php

class Model_Paciente extends CI_Model{
	function insertar($data){
		$this -> db -> insert('paciente',$data);
		}


	function getAll(){
		$query = $this -> db -> get('paciente');
		return $query -> result();
	}
}

?>