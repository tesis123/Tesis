<?php

class Model_Caso extends CI_Model{
	function insertar($data){
		$this -> db -> insert('caso',$data);
		}

	
	function getAll(){
		$query = $this -> db -> get('caso');
		return $query -> result();
	}
}

?>
