<center><h1> Login </h1></center>
<br />
<div class="container">
	<?php echo form_open(base_url() . 'Usuario/validar'); ?>
	
<label>UserName :</label>
<input type="text" name="username" id="name" placeholder="username"/><br /><br />
<label>Password :</label>
<input type="password" name="password" id="password" placeholder="**********"/><br/><br />
<input type="submit" value=" Login " name="submit"/><br />
<?php echo form_close(); ?>

	<div class="row">
		<div class="col-md-12">
				<?php echo validation_errors(); ?>
		</div>
	</div>
	<?php echo form_close(); ?>
</div>