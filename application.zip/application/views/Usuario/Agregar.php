<center><h1> Pagina de agregar Contactos </h1></center>
<br />
<div class="container">
	<?php echo form_open(base_url() . 'Usuario/AgregarUsuario'); ?>


<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Usuario:</span>
				<input type="text" class="form-control" placeholder="Tu usuario aquí:" name="nusuario" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />

	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Clave:</span>
				<input type="text" class="form-control" placeholder="Tu clave aquí:" name="nclave" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />
	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Id_Perfil:</span>
				<input type="text" class="form-control" placeholder="Tu id_perfil aquí:" name="nid_perfil" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	
	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Estado:</span>
									<label><input class="form-control" name="nestado" type="radio" value="A" >Activo</label>
									<label><input class="form-control" name="nestado" type="radio" value="I" >Inactivo</label>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Cedula:</span>
				<input type="text" class="form-control" placeholder="Tu cedula aquí:" name="ncedula" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>



	<br />
                       
<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Nombre:</span>
				<input type="text" class="form-control" placeholder="Tu nombre aquí:" name="nnombre" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />



	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Apellido:</span>
				<input type="text" class="form-control" placeholder="Tu apellido aquí:" name="napellido" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />

	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Email:</span>
				<input type="text" class="form-control" placeholder="Tu email aquí:" name="nemail" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />

	<div class="row">
		<div class="col-md-12">
			<button type="submit" class="btn btn-success pull-right">Guardar</button>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
				<?php echo validation_errors(); ?>
		</div>
	</div>
	<?php echo form_close(); ?>
</div>