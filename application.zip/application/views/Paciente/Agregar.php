<center><h1> Pagina de agregar Paciente </h1></center>
<br />
<div class="container">
	<?php echo form_open(base_url() . 'Paciente/AgregarPaciente'); ?>

<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Estado:</span>
									<label><input class="form-control" name="nestado" type="radio" value="A" >Activo</label>
									<label><input class="form-control" name="nestado" type="radio" value="I" >Inactivo</label>
			</div>
		</div>
	</div>

<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Nombre:</span>
				<input type="text" class="form-control" placeholder="Tu nombre aquí:" name="nnombre" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />

	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Apellido:</span>
				<input type="text" class="form-control" placeholder="Tu apellido aquí:" name="napellido" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />
	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Direccion:</span>
				<input type="text" class="form-control" placeholder="Tu direccion aquí:" name="ndireccion" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>



	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Telefono:</span>
				<input type="text" class="form-control" placeholder="Tu telefono aquí:" name="ntelefono" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />
                      
	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Email:</span>
				<input type="text" class="form-control" placeholder="Tu email aquí:" name="nemail" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>



	<br />

<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Sintomas:</span>
				<input type="text" class="form-control" placeholder="Tu sintomas aquí:" name="nsintomas" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />



	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Drogeria:</span>
				<input type="text" class="form-control" placeholder="Tu drogueria aquí:" name="ndrogueria" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />

<div class="form-group">
                       		<label  class="control-label col-sm-2" name="nlista_llamada" for="lista_llamada">Llamada #:</label>
								<div >
									<label><input name="nlista_llamada" type="radio" value="1" >1</label>
									<label><input name="nlista_llamada" type="radio" value="2" >2</label>
									<label><input name="nlista_llamada" type="radio" value="3" >3</label>
								</div>
	<br />
	<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Id Caso:</span>
				<input type="text" class="form-control" placeholder="Tu Id caso aquí:" name="nid_caso" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />

		<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Id Usuario:</span>
				<input type="text" class="form-control" placeholder="Tu Id usuario aquí:" name="nid_usuario" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />

	<div class="row">
		<div class="col-md-12">
			<button type="submit" class="btn btn-success pull-right">Guardar</button>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
				<?php echo validation_errors(); ?>
		</div>
	</div>
	<?php echo form_close(); ?>
</div>