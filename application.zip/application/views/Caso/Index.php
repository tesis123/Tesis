<div class="container">
    <link href="<?php echo base_url(); ?>assests/css/filter.css" rel="stylesheet">
    <script src="<?php echo base_url(); ?>assests/js/filter.js"></script>
    <div class="row">
        <div class="panel panel-primary filterable">
            <div class="panel-heading">
                <h3 class="panel-title">Casos</h3>
                   <div class="pull-right">
                    <button class="btn btn-default btn-xs btn-filter"><span class="glyphicon glyphicon-filter"></span> Filter</button>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr class="filters">
                        <th><input type="text" class="form-control" placeholder="#" disabled></th>
                        <th><input type="text" class="form-control" placeholder="Estado" disabled></th>
                    </tr>
                </thead>
                <tbody>

			<?php 
				foreach ($query as $row) {?>
                    <tr>
                        <td><center><?php echo $row -> id_caso;?></center></td>
                        <td><center><?php echo $row -> nom_estado;?></center></td>
                        
                    </tr>
            <?php
						}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>
