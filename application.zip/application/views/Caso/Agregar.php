<center><h1> Pagina de agregar Caso </h1></center>
<br />
<div class="container">
	<?php echo form_open(base_url() . 'Caso/AgregarCaso'); ?>


<div class="row">
		<div class="col-md-12">
			<div class="input-group">
				<span class="input-gropu-addon" id="basic-addon1">Caso:</span>
				<input type="text" class="form-control" placeholder="Tu caso aquí:" name="ncaso" aria-describedby="basic-addon1">
			</div>
		</div>
	</div>

	<br />


	<div class="row">
		<div class="col-md-12">
			<button type="submit" class="btn btn-success pull-right">Guardar</button>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
				<?php echo validation_errors(); ?>
		</div>
	</div>
	<?php echo form_close(); ?>
</div>